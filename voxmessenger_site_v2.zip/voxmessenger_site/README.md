# VOX Messenger Landing Page

Python/Flask landing page for `voxMessenger.lol`.

## Самый простой запуск

Первый запуск подготовит сайт и покажет, что было изменено:

```bash
python3 run.py
```

После этого запусти ещё раз:

```bash
python3 run.py
```

Со второго запуска сайт будет работать на:

```text
http://IP_ТВОЕГО_VPS:5000
```

Можно также запускать так:

```bash
./start.sh
```

## Если появилась ошибка с venv

На Ubuntu/Debian установи нужные пакеты:

```bash
sudo apt update
sudo apt install python3-venv python3-pip -y
```

## Production через Gunicorn

После первого запуска:

```bash
source venv/bin/activate
gunicorn -w 2 -b 127.0.0.1:5000 app:app
```
